import { useState, useRef, useEffect } from 'react'
import axios from 'axios'
import { motion, AnimatePresence } from 'framer-motion'

function App() {
  const [messages, setMessages] = useState([])
  const [isListening, setIsListening] = useState(false)
  const [inputText, setInputText] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [selectedScenario, setSelectedScenario] = useState('vc')
  const [selectedVoice, setSelectedVoice] = useState(null)
  const [uploadedFile, setUploadedFile] = useState(null)
  const [fileContent, setFileContent] = useState('')
  const chatEndRef = useRef(null)
  const recognitionRef = useRef(null)
  const fileInputRef = useRef(null)

  const scenarios = {
    vc: { name: 'Venture Capital', icon: '💰', color: 'from-emerald-500 to-teal-500' },
    journalist: { name: 'Journalist', icon: '🎙️', color: 'from-red-500 to-orange-500' },
    politician: { name: 'Congress', icon: '🏛️', color: 'from-blue-500 to-indigo-500' },
    ceo: { name: 'Board Member', icon: '💼', color: 'from-purple-500 to-pink-500' }
  }

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  // Load voices
  useEffect(() => {
    const loadVoices = () => {
      const voices = window.speechSynthesis.getVoices()
      const femaleVoice = voices.find(v => 
        v.name.includes('Google UK English Female') ||
        v.name.includes('Samantha') ||
        v.name.includes('Zira')
      )
      setSelectedVoice(femaleVoice || voices.find(v => v.lang === 'en-US') || null)
    }
    
    if (window.speechSynthesis) {
      window.speechSynthesis.getVoices()
      window.speechSynthesis.onvoiceschanged = loadVoices
      loadVoices()
    }
  }, [])

  const initSpeechRecognition = () => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition
    if (!SpeechRecognition) {
      alert('Speech recognition not supported in this browser')
      return null
    }
    
    const recognition = new SpeechRecognition()
    recognition.continuous = false
    recognition.interimResults = false
    recognition.lang = 'en-US'
    
    recognition.onresult = (event) => {
      setInputText(event.results[0][0].transcript)
      setIsListening(false)
    }
    
    recognition.onerror = () => setIsListening(false)
    recognition.onend = () => setIsListening(false)
    
    return recognition
  }

  const startListening = () => {
    if (!recognitionRef.current) {
      recognitionRef.current = initSpeechRecognition()
    }
    if (recognitionRef.current) {
      setIsListening(true)
      recognitionRef.current.start()
    }
  }

  const speakText = (text) => {
    if (!window.speechSynthesis) return
    window.speechSynthesis.cancel()
    const utterance = new SpeechSynthesisUtterance(text)
    utterance.rate = 0.9
    if (selectedVoice) utterance.voice = selectedVoice
    window.speechSynthesis.speak(utterance)
  }

  const handleFileUpload = async (e) => {
    const file = e.target.files[0]
    if (!file) return
    
    setUploadedFile(file)
    
    // Read file content
    const reader = new FileReader()
    reader.onload = async (event) => {
      const content = event.target.result
      setFileContent(content)
      
      // Add to chat as context
      const contextMessage = {
        role: 'system',
        content: `[User uploaded: ${file.name}]\n\nContent:\n${content.substring(0, 2000)}...`
      }
      
      // You can send this to backend or just show as context
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: `📄 I've received "${file.name}". I'll use this to inform our discussion. What would you like me to focus on from this document?`
      }])
    }
    reader.readAsText(file)
  }

  const sendMessage = async () => {
    if (!inputText.trim() && !fileContent) return
    
    const userMessage = { role: 'user', content: inputText || '[File uploaded for context]' }
    setMessages(prev => [...prev, userMessage])
    setInputText('')
    setIsLoading(true)
    
    try {
      let messageToSend = inputText
      if (fileContent && !inputText) {
        messageToSend = `Based on this document: ${fileContent.substring(0, 1000)}... What are your thoughts?`
      } else if (fileContent) {
        messageToSend = `Context from uploaded file: ${fileContent.substring(0, 500)}...\n\nMy question: ${inputText}`
      }
      
      const response = await axios.post(`${import.meta.env.VITE_API_URL}/api/chat`, {
        message: messageToSend,
        scenario: selectedScenario
      })
      
      const aiMessage = { role: 'assistant', content: response.data.reply }
      setMessages(prev => [...prev, aiMessage])
      speakText(response.data.reply)
      
    } catch (error) {
      setMessages(prev => [...prev, { 
        role: 'assistant', 
        content: 'Connection error. Make sure the backend is running.' 
      }])
    } finally {
      setIsLoading(false)
    }
  }

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      sendMessage()
    }
  }

  const clearChat = () => {
    setMessages([])
    setFileContent('')
    setUploadedFile(null)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900">
      <div className="max-w-4xl mx-auto px-4 py-6">
        {/* Header */}
        <motion.div 
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="text-center mb-8"
        >
          <h1 className="text-4xl font-light tracking-tight text-white">
            Deal<span className="font-bold text-yellow-400">Coach</span>
          </h1>
          <p className="text-gray-400 mt-2">AI-powered negotiation training</p>
        </motion.div>

        {/* Scenario Selector */}
        <div className="grid grid-cols-4 gap-2 mb-6">
          {Object.entries(scenarios).map(([key, scenario]) => (
            <button
              key={key}
              onClick={() => setSelectedScenario(key)}
              className={`py-3 rounded-xl transition-all text-sm font-medium ${
                selectedScenario === key
                  ? `bg-gradient-to-r ${scenario.color} text-white shadow-lg`
                  : 'bg-white/5 text-gray-400 hover:bg-white/10'
              }`}
            >
              <span className="mr-2">{scenario.icon}</span>
              {scenario.name}
            </button>
          ))}
        </div>

        {/* Chat Container */}
        <div className="bg-white/5 rounded-2xl border border-white/10 overflow-hidden mb-4" style={{ height: 'calc(100vh - 380px)' }}>
          <div className="h-full overflow-y-auto p-4 space-y-4">
            {messages.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full text-center">
                <div className="w-16 h-16 rounded-full bg-gradient-to-r from-yellow-400 to-orange-500 flex items-center justify-center text-2xl mb-4">
                  🎯
                </div>
                <p className="text-gray-300">Ready to practice negotiation?</p>
                <p className="text-gray-500 text-sm mt-2">Type a message or upload a document to analyze</p>
              </div>
            ) : (
              messages.map((msg, idx) => (
                <div
                  key={idx}
                  className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-[70%] px-4 py-2 rounded-2xl ${
                      msg.role === 'user'
                        ? 'bg-yellow-500 text-gray-900'
                        : 'bg-white/10 text-gray-200'
                    }`}
                  >
                    {msg.content}
                  </div>
                </div>
              ))
            )}
            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-white/10 px-4 py-2 rounded-2xl">
                  <div className="flex gap-1">
                    <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></span>
                    <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></span>
                    <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></span>
                  </div>
                </div>
              </div>
            )}
            <div ref={chatEndRef} />
          </div>
        </div>

        {/* File Upload */}
        <div className="flex gap-2 mb-3">
          <button
            onClick={() => fileInputRef.current?.click()}
            className="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-gray-400 text-sm transition-all"
          >
            📎 Upload Document
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept=".txt,.pdf,.docx,.md"
            onChange={handleFileUpload}
            className="hidden"
          />
          {uploadedFile && (
            <span className="text-xs text-gray-500 self-center">
              📄 {uploadedFile.name}
            </span>
          )}
        </div>

        {/* Input Area */}
        <div className="flex gap-3">
          <button
            onClick={startListening}
            disabled={isLoading}
            className={`w-12 h-12 rounded-full flex items-center justify-center transition-all ${
              isListening ? 'bg-red-500 animate-pulse' : 'bg-white/10 hover:bg-white/20'
            }`}
          >
            🎤
          </button>
          
          <textarea
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Type your message..."
            disabled={isLoading}
            rows={1}
            className="flex-1 px-4 py-3 bg-white/10 border border-white/10 rounded-xl text-white placeholder-gray-500 focus:outline-none focus:border-yellow-500 resize-none"
          />
          
          <button
            onClick={sendMessage}
            disabled={isLoading || (!inputText.trim() && !fileContent)}
            className="w-12 h-12 rounded-full bg-gradient-to-r from-yellow-500 to-orange-500 flex items-center justify-center disabled:opacity-50"
          >
            ➤
          </button>
        </div>

        {/* Clear Chat */}
        {messages.length > 0 && (
          <button
            onClick={clearChat}
            className="mt-3 w-full py-2 text-gray-500 text-sm hover:text-gray-300 transition-all"
          >
            Clear conversation
          </button>
        )}
      </div>
    </div>
  )
}

export default App